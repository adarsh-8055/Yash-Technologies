
package com.parking.model;
public class Booking {
 public String user;
 public int slot;
 public int hours;
}
