
package com.parking.dao;
import java.sql.*;
import com.parking.util.DBUtil;

public class BookingDAO {
 public void save(String user,int slot,int hours){
  try(Connection con=DBUtil.getConnection()){
   PreparedStatement ps=con.prepareStatement(
   "insert into bookings(username,slot,hours) values(?,?,?)");
   ps.setString(1,user);
   ps.setInt(2,slot);
   ps.setInt(3,hours);
   ps.executeUpdate();
  }catch(Exception e){e.printStackTrace();}
 }
}
