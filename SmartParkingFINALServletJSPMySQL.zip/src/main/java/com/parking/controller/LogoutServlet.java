
package com.parking.controller;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LogoutServlet extends HttpServlet{
 protected void doGet(HttpServletRequest r,HttpServletResponse s)
 throws ServletException,IOException{
  HttpSession session=r.getSession(false);
  if(session!=null) session.invalidate();
  s.sendRedirect("login.jsp");
 }
}
