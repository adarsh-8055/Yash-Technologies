
package com.parking.controller;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import com.parking.dao.BookingDAO;

public class BookingServlet extends HttpServlet {
 protected void doPost(HttpServletRequest r,HttpServletResponse s)
 throws ServletException,IOException{

  HttpSession session=r.getSession(false);
  if(session==null){s.sendRedirect("login.jsp");return;}

  String user=(String)session.getAttribute("user");
  int slot=Integer.parseInt(r.getParameter("slot"));
  int hours=Integer.parseInt(r.getParameter("hours"));

  new BookingDAO().save(user,slot,hours);
  r.setAttribute("msg","Booking Confirmed!");
  r.getRequestDispatcher("success.jsp").forward(r,s);
 }
}
